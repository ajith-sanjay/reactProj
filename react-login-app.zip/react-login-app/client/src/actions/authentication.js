import axios from 'axios';
import { GET_ERRORS, SET_CURRENT_USER, FETCH_START, FETCH_SUCCESS,FETCH_FAIL } from './types';
import setAuthToken from '../setAuthToken';
import jwt_decode from 'jwt-decode';

export const registerUser = (user, history) => dispatch => {

    dispatch({type: FETCH_START });
    axios.post( '/api/users/register', user )
            .then(res => {
                dispatch({type: FETCH_SUCCESS });
                alert('Your data submitted successfully');
                history.push('/loginhome/login')
            })
            .catch(err => {
                errorhandle(err , dispatch);
            });
}

export const loginUser = (user , history) => dispatch => {
    dispatch({type: FETCH_START });
    axios.post('/api/users/login', user)
            .then(res => {
                const { token } = res.data;
                localStorage.setItem('jwtToken', token);
                setAuthToken(token);
                const decoded = jwt_decode(token);
                dispatch(setCurrentUser(decoded));
                history.push('/');
                dispatch({type: FETCH_SUCCESS });
            })
            .catch(err => {
                errorhandle(err , dispatch);
            });
}

export const setCurrentUser = decoded => {
    return {
        type: SET_CURRENT_USER,
        payload: decoded
    }
}

export const errorhandle = (error , dispatch) => {
    if(!error.response){
        alert('Your request could not be processed due to network issue.pleae try after some time....');
    }
    else{
        dispatch({
            type: GET_ERRORS,
            payload: error.response.data || {commonIssue : 'network error'}
        });
    }
    dispatch({type: FETCH_FAIL });
}

export const logoutUser = (history) => dispatch => {
    localStorage.removeItem('jwtToken');
    setAuthToken(false);
    dispatch(setCurrentUser({}));
    history.push('/loginhome/login');
}