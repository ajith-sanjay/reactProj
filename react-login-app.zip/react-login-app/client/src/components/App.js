import React from 'react';
import LoginHome from './LoginHome';
import UserHome from './UserHome';
import { Route, Redirect , withRouter} from 'react-router-dom';
import {connect} from 'react-redux';


const PrivateRoute = ({ component: Component, login , ...rest }) => (
    <Route {...rest} render={props => (
        login.isAuthenticated
            ? <Component {...props} />
            : <Redirect to='/loginhome/login' />
    )} />
);

class App extends React.Component{ 
	
	render(){
			return(
				<div>
					<PrivateRoute exact path="/" component={UserHome} login={this.props.auth}/>
					<Route path="/loginhome" component={LoginHome}/>
				</div>
			)
	}
}

const mapStateToProps = (state) => ({
  auth : state.auth
});

export default withRouter(connect(mapStateToProps)(App));





