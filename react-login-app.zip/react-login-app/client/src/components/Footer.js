import React from "react";
import '../styles/footer.css';
import '../styles/styleForUserPage.css';
import { Container ,Row, Col } from 'react-bootstrap';

const Footer = () => (
    <div className = "footer-container">
	    <Row className ="footer-flex-container">
	    	<Col sm={12} md={3}> 
	    		<div className = "font-24">COPYRIGHT</div>
	    		<div className = "font-26">REACT LOGIN</div>
	    		<div className="brand_icons font-22">
                    <span className="fa fa-facebook inline"></span>
                    <span className="fa fa-google-plus inline"></span>
                    <span className="fa fa-pinterest inline"></span>
                    <span className="fa fa-twitter inline"></span>
                </div>
	    	</Col>
	    	<Col sm={12} md={3} className = "footer-list-copyright footer-content-color">
	    		<span><span className="fa fa-copyright"></span><span> 2019 DESIGNED BY</span></span>
	    		<span>REACTLOGIN.COM</span>
	    	</Col>
	    	<Col sm={12} md={3} className="footer-contact-list">
	    		<span className = "font-24">CONTACTS</span><br/>
	    		<span>9870 ST VINCENT PLACE,</span><br/>
	    		<span>GLASGOW, DC 45 FR 45.</span><br/>
	    		<span>Telephone:+91 987654321</span><br/>
	    		<span>E-MAIL:xyz@gmail.com</span><br/>
	    	</Col>
	    </Row>
	</div>
);

export default Footer;