import React, {Fragment} from 'react';
import { Link } from 'react-router-dom';
import './../styles/style.css';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { loginUser } from '../actions/authentication';
import classnames from 'classnames';

class Login extends React.Component{ 
	constructor(props) {
		super(props);
		this.state = {
			usernameLogin : "",
			passwordLogin : "",
            errors: {}
		}
	}
	updateForm(e){
		this.setState({
			[e.target.name] : e.target.value
		});
	}
	handleSubmit(event) {
	    event.preventDefault();
	    const user = {
	            email: this.state.usernameLogin,
	            password: this.state.passwordLogin,
	        }
	        this.props.loginUser(user , this.props.history);

	  }
	componentDidMount() {
        if(this.props.auth.isAuthenticated) {
            this.props.history.push('/');
        }
    }

    componentWillReceiveProps(nextProps) {
        if(nextProps.auth.isAuthenticated) {
            this.props.history.push('/')
        }
        if(nextProps.errors) {
            this.setState({
                errors: nextProps.errors
            });
        }
    }
	render(){
		const {errors} = this.state;
		return(
				<Fragment>
					<form className = "userCredentials" onSubmit={this.handleSubmit.bind(this)}>
				          <label htmlFor="usernameLogin">Enter your email</label><br />
				          <input id="usernameLogin" name="usernameLogin" value = {this.state.username} type="text" onChange = {this.updateForm.bind(this)}  className={classnames('form-control', {
		                        'is-invalid': errors.email
		                    })} placeholder = "Enter email"/>
		                   <div style={{width:'100%',height : '20px'}} className={classnames({'invalid-feedback' : errors.email})}>{errors.email}</div>
				          
				          <label htmlFor="passwordLogin">Enter your password</label><br />
				          <input id="passwordLogin" name="passwordLogin" value = {this.state.password} type="password" onChange = {this.updateForm.bind(this)} className={classnames('form-control', {
		                        'is-invalid': errors.password
		                    })} placeholder = "Enter password"/>
				          <div style={{width:'100%',height : '20px'}} className={classnames({'invalid-feedback' : errors.password})}>{errors.password}</div>
				          <br />

				          <button>Sign in</button>
			        </form>
					<div className="forgetPassword">I don't have an account <Link to={'/loginhome/register'}>Register</Link></div>
				</Fragment>
			)
	}
}
Login.propTypes = {
    loginUser: PropTypes.func.isRequired,
    auth: PropTypes.object.isRequired,
    errors: PropTypes.object.isRequired
}

const mapStateToProps = (state) => ({
    auth: state.auth,
    errors: state.errors
})

export  default connect(mapStateToProps, { loginUser })(Login)