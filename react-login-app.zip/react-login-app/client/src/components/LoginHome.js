import React from 'react';
import { Route, NavLink, Switch, withRouter } from 'react-router-dom';
import './../styles/style.css';
import Login from './Login';
import Register from './Register';
import {connect} from 'react-redux';
import { Loader } from './Loader/Loader'
var lightBackground = {backgroundColor : 'rgba(0, 0, 0, 0)' , filter: 'brightness(70%)'},darkBackground = {backgroundColor : 'rgba(0, 0, 0, 0.5)'};
class LoginHome extends React.Component{ 

	constructor(props) {
		super(props);
		this.state = {
			loginStyle : lightBackground,
			registerStyle : darkBackground
		}
		console.log(this.props);
	}
	
	componentWillReceiveProps(props){
		
		if(props.location.pathname === `${this.props.match.url}/login`){
			this.setState({
				loginStyle : lightBackground,
				registerStyle : darkBackground
			});
		}
		else{
			this.setState({
				loginStyle : darkBackground,
				registerStyle : lightBackground
			});
		}
		
	}
	render(){
		
				return(
					<div className="mainPageContent">
                    {this.props.isfetching && (	
                        <Loader />
                        )}
                        <header>
                            <div className = "companyLogo"></div>
                            <div className="headerTitle">Cloud Scada</div>
                        </header>
                        <div style={{height:'100px'}}></div>
                        <nav className = "navigationOfLogin">
                            <div className = "navigationHeader">
                                <div><NavLink style={this.state.loginStyle} className="whitner" to={`${this.props.match.url}/login`}>Login</NavLink></div>
                                <div><NavLink style={this.state.registerStyle} className="whitner" to={`${this.props.match.url}/register`}>Register</NavLink></div>
                            </div>
                            <div style={{margin: '10px'}}>
                                <div style={{margin: '15px'}}>
                                    <Switch>
                                        
                                        <Route path = {`${this.props.match.path}/login`} component={Login} />
                                        <Route path = {`${this.props.match.path}/register`} component={Register} />
                                    </Switch>
                                </div>
                            </div>
                        </nav>
			        </div>
			)
		
			
	}
}
const mapStateToProps = state => ({
		isfetching : state.isfetching
	});

export default connect(mapStateToProps)(withRouter(LoginHome));