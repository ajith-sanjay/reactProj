import React, {Fragment} from 'react';
import { Link, withRouter} from 'react-router-dom';
import './../styles/style.css';
import PropTypes from 'prop-types';
import { registerUser } from '../actions/authentication';
import {connect} from 'react-redux';
import classnames from 'classnames';

class Register extends React.Component{ 
	constructor(props) {
		super(props);
		this.state = {
			username : "",
			email : "",
			password : "",
			confirmPassword : "",
            errors: {}
		}
	}
	updateForm(e){
		this.setState({
			[e.target.name] : e.target.value
		});
	}
	handleSubmit(event) {
	    event.preventDefault();
	    const user = {
	            name: this.state.username,
	            email: this.state.email,
	            password: this.state.password,
	            password_confirm: this.state.confirmPassword
	        }
	        this.props.registerUser(user, this.props.history);
	  }
	componentWillReceiveProps(nextProps) {
        if(nextProps.auth.isAuthenticated) {
            this.props.history.push('/')
        }
        if(nextProps.errors) {
            this.setState({
                errors: nextProps.errors
            });
        }
    }

    componentDidMount() {
        if(this.props.auth.isAuthenticated) {
            this.props.history.push('/');
        }
    }


	render(){
		const { errors } = this.state;
		return(
			<Fragment>
				
				<form className = "userCredentials" onSubmit={this.handleSubmit.bind(this)}>
		          <label htmlFor="username">Enter username</label><br />
		          <input id="username" name="username" value = {this.state.username} type="text" onChange = {this.updateForm.bind(this)} className={classnames('form-control', {
                      'is-invalid': errors.name
                  })} placeholder = "Enter username"/>
		          <div style={{width:'100%',height : '20px'}} className={classnames({'invalid-feedback' : errors.name})}>{errors.name}</div>

		          <label htmlFor="email">Enter your email</label><br />
		          <input id="email" name="email" value = {this.state.email} type="email" onChange = {this.updateForm.bind(this)}  className={classnames('form-control', {
                      'is-invalid': errors.email
                  })} placeholder = "Enter gmail address"/>
		          <div style={{width:'100%',height : '20px'}} className={classnames({'invalid-feedback' : errors.email})}>{errors.email}</div>

		          <label htmlFor="password">Enter your password</label><br />
		          <input id="password" name="password" value = {this.state.password} type="password" onChange = {this.updateForm.bind(this)} className={classnames('form-control', {
                      'is-invalid': errors.password
                  })} placeholder = "Enter password"/>
		          <div style={{width:'100%',height : '20px'}} className={classnames({'invalid-feedback' : errors.password})}>{errors.password}</div>

		          <label htmlFor="confirmPassword">confirm password</label><br />
		          <input id="confirmPassword" name="confirmPassword" value = {this.state.confirmPassword} type="password" onChange = {this.updateForm.bind(this)} className={classnames('form-control', {
                      'is-invalid': errors.password_confirm
                  })} placeholder = "Confirm password"/>
		          
		          <div style={{width:'100%',height : '20px'}} className={classnames({'invalid-feedback' : errors.password_confirm})}>{errors.password_confirm}</div>
		          <br />
		          <button>Submit</button>
		        </form>




				<div className="forgetPassword">I already have an account <Link to={'/loginhome/login'}>Login</Link></div>	
			</Fragment>

			)
	}
}

	Register.propTypes = {
			registerUser: PropTypes.func.isRequired,
			auth: PropTypes.object.isRequired
	};

	const mapStateToProps = state => ({
		auth: state.auth,
		errors: state.errors
	});

	export default connect(mapStateToProps,{ registerUser })(withRouter(Register));