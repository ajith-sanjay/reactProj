import React from 'react';
import {connect} from 'react-redux';
import { withRouter} from 'react-router-dom';
import { bindActionCreators } from 'redux';
import { logoutUser } from '../actions/authentication';
import '../styles/styleForUserPage.css';
import img1 from './../images/img2.jpg';
import { Container ,Row, Col, Navbar, Nav, NavDropdown, Carousel, Card } from 'react-bootstrap';

import Footer from './Footer.js';


class UserHome extends React.Component{ 
	constructor(props){
		super(props);
		console.log(this.props);
	}

	render(){
		
		return(

             <div>
                <div className= "row header-1" >
                    <div className="col-sm-2 brand_icons">
                        <div className="fa fa-facebook inline"></div>
                        <div className="fa fa-google-plus inline"></div>
                        <div className="fa fa-pinterest inline"></div>
                        <div className="fa fa-twitter inline"></div>
                    </div>
                    <div className="col-sm-4 brand_icons">
                        <div className="fa fa-map-marker inline"></div>
                        <div className="inline header-1-shade">9870 St Vincent Place, Glasgow, DC 45 Fr 45.</div>
                    </div>
                    <div className="col-sm-3 brand_icons">
                        <div className="fa fa-envelope inline"></div>
                        <div className="inline header-1-shade">xyz@gmail.com</div>
                    </div>
                    <div className="col-sm-3 brand_icons">
                        <div className="fa fa-phone inline"></div>
                        <div className="inline header-1-shade">+91 987654321</div>
                    </div>
                </div>
                


                <Navbar expand="lg" style={{height : '100px'}}>
                  <Row  className="width-full-percent">
                    <Col xs={10} className = "zero-padding">
                      <div className="fa fa-empire fa-lg rotateLogo"></div>
                      <Navbar.Brand className="app-color logo-font-weight">REACT LOGIN</Navbar.Brand>
                    </Col>
                    <Col xs={2} className = "navbar-float-right zero-padding">
                      <Navbar.Toggle aria-controls="basic-navbar-nav" />
                          <Navbar.Collapse id="basic-navbar-nav">
                            <Nav className="mr-auto header-content-lists">
                              <Nav.Link href="#home">Home</Nav.Link>
                              <Nav.Link href="#link">Link</Nav.Link>
                              <NavDropdown alignRight title="Dropdown" id="basic-nav-dropdown-menu-align-right" className="dropdown-menu-list">
                                <NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
                                <NavDropdown.Item href="#action/3.2">Another action</NavDropdown.Item>
                                <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
                                <NavDropdown.Item href="#action/3.4" onClick = {() => this.props.logoutUser(this.props.history)}>Log Out</NavDropdown.Item>
                              </NavDropdown>
                            </Nav>
                          </Navbar.Collapse>
                    </Col>
                  </Row>
                </Navbar>




                <Carousel>
                  <Carousel.Item>
                    <img
                      className="d-block w-100"
                      src={require('../images/scr01.jpg')}
                      alt="First slide"
                      width="100%"
                      height="600"
                    />
                    <Carousel.Caption>
                      <h3>First slide label</h3>
                      <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
                    </Carousel.Caption>
                  </Carousel.Item>
                  <Carousel.Item>
                    <img
                      className="d-block w-100"
                      src={require('../images/scr01.jpg')}
                      alt="Second slide"
                      width="100%"
                      height="600"
                    />

                    <Carousel.Caption>
                      <h3>Second slide label</h3>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    </Carousel.Caption>
                  </Carousel.Item>
                  <Carousel.Item>
                    <img
                      className="d-block w-100"
                      src= {require('../images/scr01.jpg')}
                      alt="Third slide"
                      width="100%"
                      height="600"
                    />

                    <Carousel.Caption>
                      <h3>Third slide label</h3>
                      <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
                    </Carousel.Caption>
                  </Carousel.Item>
                </Carousel>

                <div style={{background: '#E1E2E4'}}>
                  <center className="our-location-title">Our Locations</center>
                  <div className = "site-container">
                      
                      {[1,2,3,4,5,6,7,8,9].map(() => 
                          (
                              <Card className="card-items">

                                <Card.Body style={{background : '#1F273A',color:'#fff'}}>
                                  <Card.Title>Card Title</Card.Title>
                                  <Card.Text>
                                    Some quick example text to build on the card title and make up the bulk of
                                    the card's content.
                                  </Card.Text>
                                  <div className = "fa fa-arrow-circle-right card-icon"></div>
                                </Card.Body>
                                  <Card.Img variant="top" src={require('../images/scr01.jpg')} />
                              </Card>

                          )

                      )}
                      
                          

                  </div>
                </div>

                <Footer data="test"/>

            </div>
		)
	}
}

const mapStateToProps = (state) => ({
	auth : state.auth
});

const mapDispatchToProps = (dispatch) => bindActionCreators({
	logoutUser : logoutUser
}, dispatch);
export default connect(mapStateToProps , mapDispatchToProps)(withRouter(UserHome));