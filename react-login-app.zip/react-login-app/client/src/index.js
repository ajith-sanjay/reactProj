import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import * as serviceWorker from './serviceWorker';
import { Router } from 'react-router-dom';
import App from './components/App';
import {combineReducers , createStore , applyMiddleware} from 'redux';
import { Provider } from 'react-redux';
import createBrowserHistory from 'history/createBrowserHistory';
import jwt_decode from 'jwt-decode';
import setAuthToken from './setAuthToken';
import { setCurrentUser, logoutUser } from './actions/authentication';
import {errorReducer ,fetchReducer } from './reducers/errorReducer';
import authReducer from './reducers/authReducer';
import thunk from 'redux-thunk';
import 'bootstrap/dist/css/bootstrap.min.css';

//combining all reducers
const allReducers = combineReducers({
    errors: errorReducer,
    auth: authReducer,
    isfetching : fetchReducer
});


//creating the store for state management
const store = createStore(allReducers , applyMiddleware(thunk));



if(localStorage.jwtToken) {
  setAuthToken(localStorage.jwtToken);
  const decoded = jwt_decode(localStorage.jwtToken);
  store.dispatch(setCurrentUser(decoded));

  const currentTime = Date.now() / 1000;
  if(decoded.exp < currentTime) {
    store.dispatch(logoutUser());
    window.location.href = '/loginhome/login'
  }
}

const customHistory = createBrowserHistory();

ReactDOM.render(<Provider store = {store}><Router history={customHistory}><App /></Router></Provider>, document.getElementById( 'root' ) );



// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();