import { GET_ERRORS ,FETCH_START, FETCH_SUCCESS,FETCH_FAIL } from '../actions/types';

const initialState = {};

export function errorReducer(state = initialState, action ) {
    switch(action.type) {
        case GET_ERRORS:
            return action.payload;
        default: 
            return state;
    }
}


export function fetchReducer(state = false, action ) {
    switch(action.type) {
        case FETCH_START:
            return true;
        case FETCH_SUCCESS:
            return false;
        case FETCH_FAIL:
            return false;
        default: 
            return state;
    }
}