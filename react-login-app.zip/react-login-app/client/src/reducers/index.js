import { combineReducers } from 'redux';
import { errorReducer, fetchReducer} from './errorReducer';
import authReducer from './authReducer';

export default combineReducers({
    errors: errorReducer,
    auth: authReducer,
    isfetching : fetchReducer
});